package com.example.barcode_scan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
